# Simple template to create SPA's with plain JavaScript using Babel, Webpack and Webpacks devserver

## Getting started

- If not alredy done, install nodejs and a sufficient JavaScript Editor (we suggest vs-code)
- Clone this project
- In the folder it was cloned into, type npm install
- In the folder it was cloned into (if you have installed vs-code) type "code ." to open vs-code
- In the folder it was cloned into type npm start, to run the project via Webpacks development server
# repo auto created
# repo auto created
